package bearmaps.hw4;

public enum SolverOutcome {
    SOLVED, TIMEOUT, UNSOLVABLE
}
