package hw2;


import edu.princeton.cs.algs4.WeightedQuickUnionUF;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class Percolation {

    private int size;
    private int length;
    private int[] grid;
    private int numOpen;
    private WeightedQuickUnionUF TA;
    private WeightedQuickUnionUF ds;
    private int above, left, right, below;

    private int convertTo1D(int row, int col) {
        int value = (row * length) + col;
        return value;
    }

    public Percolation(int N) {
        if (N <= 0) {
            throw new IllegalArgumentException();
        }
        size = N * N;
        length = N;
        grid = new int[size];
        for (int i = 0; i < size; i++) {
            grid[i] = 0;
        }
        ds = new WeightedQuickUnionUF(size + 2);
        TA = new WeightedQuickUnionUF(size + 2);
        for (int k = 1; k < length + 1; k++) {
            ds.union(0, k);
            TA.union(0, k);
        }
        for (int j = size - length + 1; j <= size; j++) {
            ds.union(size + 1, j);
        }

    }

    public void open(int row, int col) {
        if (isOpen(row, col)) {
            return;
        }
        int location = convertTo1D(row, col);
        grid[location] = 1;
        numOpen += 1;
        if (col > 0) {
            left = convertTo1D(row, col - 1);
            if (grid[left] == 1) {
                ds.union(left + 1, location + 1);
                TA.union(left + 1, location + 1);
            }
        }
        if (col < length - 1) {
            right = convertTo1D(row, col + 1);
            if (grid[right] == 1) {
                ds.union(right + 1, location + 1);
                TA.union(right + 1, location + 1);
            }
        }
        if (row > 0) {
            above = convertTo1D(row - 1, col);
            if (grid[above] == 1) {
                ds.union(above + 1, location + 1);
                TA.union(above + 1, location + 1);
            }
        }
        if (row < length - 1) {
            below = convertTo1D(row + 1, col);
            if (grid[below] == 1) {
                ds.union(below + 1, location + 1);
                TA.union(below + 1, location + 1);
            }
        }


    }
    public boolean isOpen(int row, int col) {
        return grid[convertTo1D(row, col)] == 1;
    }
    public boolean isFull(int row, int col) {
        if (grid[convertTo1D(row, col)] != 1) {
            return false;
        }
        return TA.connected(0, convertTo1D(row, col) + 1);

    }


    public int numberOfOpenSites() {
        return numOpen;
    }
    public boolean percolates() {
        return ds.connected(0, size + 1);
    }

    public static void main(String[] args) {
        Percolation p = new Percolation(5);
        p.open(0, 1);
        p.open(1, 1);
        p.open(2, 1);
        p.open(2, 2);
        p.open(3, 2);
        p.open(4, 2);
        p.open(4, 2);

        p.open(1, 3);
        p.open(1, 4);
        p.open(2, 4);
        p.open(3, 4);
        p.open(4, 4);

        System.out.println("passed opening test!");

        assertTrue(p.isOpen(0, 1));
        assertTrue(p.isOpen(3, 2));
        assertTrue(p.isOpen(2, 4));
        assertTrue(p.isOpen(4, 2));
        assertTrue(!p.isOpen(0, 0));
        assertTrue(!p.isOpen(3, 1));
        assertTrue(!p.isOpen(4, 0));
        assertTrue(!p.isOpen(0, 4));

        System.out.println("passed isOpen test!");

        assertTrue(p.ds.connected(18, 23));
        assertTrue(p.ds.connected(2, 13));

        System.out.println("passed connected test!");


        assertTrue(p.isFull(3, 2));
        assertTrue(p.isFull(4, 2));
        assertTrue(!p.isFull(4, 4));
        assertTrue(!p.isFull(1, 3));

        System.out.println("passed isFull test!");

        assertEquals(p.numberOfOpenSites(), 11);
        assertTrue(p.percolates());

        System.out.println("passed numberOfOpenSites and Percolates tests!");
        System.out.println("Passed All Tests!!!");


    }

}
