package hw2;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import edu.princeton.cs.introcs.StdRandom;
import edu.princeton.cs.introcs.StdStats;



public class PercolationStats {

    private double[] estimates;
    private Percolation perc;
    private WeightedQuickUnionUF temp;

    private int convertTo1D(int row, int col, int length) {
        int value = (row * length) + col;
        return value;
    }

    public PercolationStats(int N, int T, PercolationFactory pf) {
        if (N <= 0 || T <= 0) {
            throw new IllegalArgumentException();
        }
        estimates = new double[T];


        for (int i = 0; i < T; i++) {
            perc = pf.make(N);
            temp = new WeightedQuickUnionUF(N * N + 1);
            while (!perc.percolates()) {
                /* tried a double array here that reduced size when a site was opened
                 * way too tedious...don't over think */

                int column = StdRandom.uniform(0, N); /* doesn't include upper bound */
                int row = StdRandom.uniform(0, N);
                if (!temp.connected(N * N, convertTo1D(row, column, N))) {
                    temp.union(N * N, convertTo1D(row, column, N));
                    perc.open(row, column);
                }
            }
            estimates[i] = perc.numberOfOpenSites() / (N * N);

        }
    }
    public double mean() {
        return StdStats.mean(estimates);
    }
    public double stddev() {
        return StdStats.stddev(estimates);
    }
    public double confidenceLow() {
        return mean() - ((1.96 * stddev()) / Math.sqrt(estimates.length));
    }
    public double confidenceHigh() {
        return mean() + ((1.96 * stddev()) / Math.sqrt(estimates.length));
    }


}
