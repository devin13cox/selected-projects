package byow.Core;
import org.junit.Test;




public class Tests {

    @Test
    public  void l() {
        Engine engine = new Engine();
        engine.interactWithInputString("n7313251667695476404sasdw");

    }
}
//
