public class Body {
	public double xxPos;
	public double yyPos;
	public double xxVel;
	public double yyVel;
	public double mass;
	public String imgFileName;

	public Body(double xP, double yP, double xVel, 
		double yVel, double m, String img){	
		this.xxPos = xP;
		this.yyPos = yP;
		this.xxVel = xVel;
		this.yyVel = yVel;
		this.mass = m;
		this.imgFileName = img;
		}
	public Body(Body b){
		this.xxPos = b.xxPos;
		this.yyPos = b.yyPos;
		this.xxVel = b.xxVel;
		this.yyVel = b.yyVel;
		this.mass = b.mass;
		this.imgFileName = b.imgFileName;
		}
	public double calcDistance(Body b){
		/**returns total distance between object and Body b */
		double dx = this.xxPos - b.xxPos;
		double dy = this.yyPos - b.yyPos;
		double rsq = (dx*dx) +(dy*dy);
		return Math.sqrt(rsq);
	}	
	public double calcForceExertedBy(Body b){
		/** returns total Force exerted onto object from Body b */
		double g = 6.67*10e-12;
		double r = this.calcDistance(b);
		double exforce = (g*this.mass*b.mass)/(r*r);
		return exforce;
	}
	public double calcForceExertedByX(Body b){
		/** Exerted Force in X direction */
		double r = this.calcDistance(b);
		double xxforce = (this.calcForceExertedBy(b)*(
			b.xxPos - this.xxPos))/r;
		return xxforce;
	}
	public double calcForceExertedByY(Body b){
		/** exerted force in y direction */
		double r = this.calcDistance(b);
		double yyforce = (this.calcForceExertedBy(b)*(
			b.yyPos - this.yyPos))/r;
		return yyforce;
	}
	public double calcNetForceExertedByX(Body[] bodies){
		/** Net force from all objects in x direction */
		int length = bodies.length;
		double sum = 0;
		while (length > 0){
			if (this.equals(bodies[length - 1])){
				length--;
			}
			else{
				sum = sum + this.calcForceExertedByX(
					bodies[length - 1]);
				length--;
			}
		}
		return sum;
	}
	public double calcNetForceExertedByY(Body[] bodies){
		/** Net force from all objects in y direction */
		int length = bodies.length;
		double sum = 0;
		while (length > 0){
			if (this.equals(bodies[length - 1])){
				length--;
			}
			else{
				sum = sum + this.calcForceExertedByY(
					bodies[length - 1]);
				length--;
			}
		}
		return sum;
	}
	public void update(double dt, double fX, double fY){
		double xxAccel = fX/this.mass;
		double yyAccel = fY/this.mass;
		this.xxVel = this.xxVel + xxAccel*dt;
		this.yyVel = this.yyVel + yyAccel*dt;
		this.xxPos = this.xxPos + dt*this.xxVel;
		this.yyPos = this.yyPos + dt*this.yyVel;
	}
	public void draw(){
		StdDraw.enableDoubleBuffering();
		String temp = String.format("images/" + this.imgFileName);
		StdDraw.picture(this.xxPos, this.yyPos, temp);
		StdDraw.show();

	}
}


