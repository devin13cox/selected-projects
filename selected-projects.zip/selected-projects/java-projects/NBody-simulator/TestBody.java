public class TestBody {
	Body firstTest = new Body(double 0, double 0, double 0
		double 0, double 0, String img);
	Body secondTest = new Body(double 1, double 2, double 3,
		double 4, double 5, String img);
	
}