public class NBody {
	public static double readRadius(String universe){
		In in = new In(universe);
		int num_planets = in.readInt();
		double rad_univ = in.readDouble();
		return rad_univ;
		
	}
	public static Body[] readBodies(String universe){
		In in = new In(universe);
		int num_planets = in.readInt();
		double rad_univ = in.readDouble();
		Body[] bodies = new Body[num_planets];
		int index = 0;
		while (num_planets != 0){
			double xxPos = in.readDouble();
			double yyPos = in.readDouble();
			double xxVel = in.readDouble();
			double yyVel = in.readDouble();
			double mass = in.readDouble();
			String img = in.readString();
			bodies[index] = new Body(xxPos, yyPos, xxVel, yyVel, 
				mass, img);
			index++;
			num_planets--;
		}
		return bodies;
	}
	public static void main(String[] args){

		double t = Double.parseDouble(args[0]);
		double dt = Double.parseDouble(args[1]);
		String filename = args[2];
		double rad_univ = readRadius(filename);
		Body[] universe = readBodies(filename);

		StdDraw.enableDoubleBuffering();
		StdDraw.setScale(-rad_univ, rad_univ);
		StdDraw.clear();

		double time = 0;
		while (time < t){
			double[] xForces = new double[universe.length];
			double[] yForces = new double[universe.length];
			for (int x = 0; x < universe.length; x++){
				xForces[x] = universe[x].calcNetForceExertedByX(universe);
				yForces[x] = universe[x].calcNetForceExertedByY(universe);
			}
			for (int x = 0; x < universe.length; x++){
				universe[x].update(dt, xForces[x], yForces[x]);
			}
			StdDraw.picture(-rad_univ, rad_univ, "images/starfield.jpg");
			StdDraw.picture(rad_univ, rad_univ, "images/starfield.jpg");
			StdDraw.picture(-rad_univ, -rad_univ, "images/starfield.jpg");
			StdDraw.picture(rad_univ, -rad_univ, "images/starfield.jpg");
			for(int x = 0; x < universe.length; x++){
				universe[x].draw();
			}
			StdDraw.show();
			StdDraw.pause(10);
			time += dt;
		}
		
		StdOut.printf("%d\n", universe.length);
		StdOut.printf("%.2e\n", rad_univ);
		for (int i = 0; i < universe.length; i++){
			StdOut.printf("%11.4e %11.4e %11.4e %11.4e %11.4e %12s\n" , 
				universe[i].xxPos, universe[i].yyPos, universe[i].xxVel, 
				universe[i].yyVel, universe[i].mass, universe[i].imgFileName);
		}


		

	}

}